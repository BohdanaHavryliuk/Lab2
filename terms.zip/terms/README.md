# Terms

A Pen created on CodePen.io. Original URL: [https://codepen.io/bogdanagav/pen/EaYVeWM](https://codepen.io/bogdanagav/pen/EaYVeWM).

